const bcrypt = require('bcryptjs');
const chalk = require('chalk');
const password = "password123"
var salt = bcrypt.genSaltSync(10);
var hash = bcrypt.hashSync(password, salt);
console.log(`${chalk.red('Hashed Password : ')}${chalk.green(hash)}`);